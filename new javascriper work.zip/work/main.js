

class UniqueBank {

    #staff = ['hamza', 'bilal']
    #Roles = ['ADMIN', 'USER']
    #Accounts = []
    constructor() {

    }


    getStaff() {
        console.log(this.#staff);
    }
    createStaff(users, user) {
        const allowedRoles = ['ADMIN']
        if (allowedRoles.includes(user)) {
            if (users.length >= 1) {
                users.forEach((val, index, arr) => {
                    this.#staff.push(val)
                })
            }
        } else {
            console.error('you are not allowed to create staff')
        }
    }
    createAccount(userCnic) {
        if (!userCnic && userCnic.length<15) {
            return console.error('Invalid CNIC')
        }
        // if(this.#Accounts)
        const randomCardNo = Math.ceil(Math.random() * 99999999999)
        const randomCardPin = Math.ceil(Math.random() * 9999)
        const aYearFromNow = new Date();
        aYearFromNow.setFullYear(aYearFromNow.getFullYear() + 1);

        const newUserCard = {
            cnic: userCnic,
            cardNo: randomCardNo,
            cardPin: randomCardPin,
            cardExpiry: aYearFromNow,
        }

        // persistant
        const oldData=localStorage.getItem('account')
        localStorage.setItem('account',JSON.stringify([JSON.parse(oldData),newUserCard]))

        this.#Accounts.push(newUserCard)
    }
    allAcounts() {
        console.log(this.#Accounts);
    }
}

const Bank=new UniqueBank()
// Bank.getStaff()
// const newStaff=['amna']
// Bank.createStaff(newStaff,'ADMIN')
// Bank.getStaff()
Bank.createAccount('567567567567567')
Bank.allAcounts()

