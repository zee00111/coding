

class HBL {
    #staff = ['hamza', 'bilal']
    #Roles = ['ADMIN', 'USER']
    constructor() {

    }


    getStaff() {
        console.log(this.#staff);
    }
    createStaff(users, user) {
        const allowedRoles = ['ADMIN']
        if (allowedRoles.includes(user)) {
            if (users.length >= 1) {
                users.forEach((val, index, arr) => {
                    this.#staff.push(val)
                })
            }
        } else {
            console.error('you are not allowed to create staff')
        }
    }
}

const Bank=new HBL()
Bank.getStaff()
const newStaff=['amna']
Bank.createStaff(newStaff,'USER')