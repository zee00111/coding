import React from "react";

const Services = () => {
  return (
    <section className="py-24 mt-2 bg-gray-100 dark:bg-gray-900" id="services">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12" data-aos="fade-up">
          <p className="dark:text-indigo-600 text-indigo-600 text-lg font-semibold">Services</p>
          <h2 className="text-4xl font-bold dark:text-white">Specialized in</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div
            className="bg-white rounded-lg shadow-md p-8 transform transition duration-300 hover:scale-105 hover:shadow-lg" data-ao="fade-up" data-aos="flip-right"
           
            data-aos-delay="100"
          >
            <div className="flex items-center justify-center mb-4">
              <img
                src="https://e7.pngegg.com/pngimages/262/104/png-clipart-website-development-web-design-web-application-web-developer-world-wide-web-web-design-search-engine-optimization-web-design.png"
                className="w-12 h-12 text-indigo-600"
              />
            </div>
            <h4 className="text-2xl font-semibold text-gray-900 mb-2 text-center ">
              SEO Development
            </h4>
            <p className="text-gray-600">
            "Optimize your website to rank higher in search engine results, attract more organic traffic, and increase your online visibility. Our SEO strategies are tailored to meet your business goals and target audience."
            </p>
          </div>
          <div
            className="bg-white rounded-lg shadow-md p-8 transform transition duration-300 hover:scale-105 hover:shadow-lg"
            // data-aos="fade-down"
            data-aos-delay="300 "
            data-aos="flip-right"
           
           
          >
            <div className="flex items-center justify-center mb-4">
              <img
                src="https://static.vecteezy.com/system/resources/thumbnails/008/506/590/small/3d-seo-search-engine-optimization-concept-3d-rendering-png.png"
                alt="Web Development Icon"
                className="w-12 h-12 text-indigo-600"
              />
            </div>
            <h4 className="text-2xl font-semibold text-gray-900 mb-2 text-center">
              Web Development
            </h4>
            <p className="text-gray-600">
            "Build and maintain responsive, user-friendly websites that provide a seamless experience across all devices. Our web development services ensure high performance, security, and scalability to support your growing business needs."
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
