
"use client";
import React from "react";


import { Footer } from "flowbite-react";
import { BsDribbble, BsFacebook, BsGithub, BsInstagram, BsTwitter } from "react-icons/bs";

export function CustomFooter () {
  return (
    <Footer className=" bg-gray-100 dark:bg-gray-900 mt-1 "data-aos="fade-up"
    data-aos-delay="900">
      <div className="w-full">
        <div className="grid w-full justify-between sm:flex sm:justify-between md:flex md:grid-cols-1">
          <div>
            <Footer.Brand
              href="#"
            src="https://w7.pngwing.com/pngs/7/748/png-transparent-letter-case-z-english-alphabet-z-letter-logo-angle-text-rectangle.png"

              alt="zain Logo"
              name="Zain Qureshi"className="mt-3 p-3"data-aos="fade-up"
              data-aos-delay="400"
            />
          </div>
          <div className="mb-5 grid grid-cols-2 gap-8 sm:mt-4 sm:grid-cols-3 sm:gap-6" data-aos="fade-up"
      data-aos-delay="600">
           
            <div>
              <Footer.Title title="Follow us" />
              <Footer.LinkGroup col>
                <Footer.Link href="#">Github</Footer.Link>
                <Footer.Link href="#">Discord</Footer.Link>
              </Footer.LinkGroup>
            </div>
            <div>
              <Footer.Title title="Legal" />
              <Footer.LinkGroup col>
                <Footer.Link href="#">Privacy Policy</Footer.Link>
                <Footer.Link href="#">Terms &amp; Conditions</Footer.Link>
              </Footer.LinkGroup>
            </div>
          </div>
        </div>
        <Footer.Divider />
        <div className="mt-2 p-6 w-full h-10 sm:flex sm:items-center sm:justify-between"data-aos="fade-up"
      data-aos-delay="100">
          <Footer.Copyright href="#" by=" Zain Qureshi™" year={2024} />
          <div className= " mt-4 flex space-x-6 sm:mt-0 sm:justify-center">
            <Footer.Icon href="#" icon={BsFacebook} />
            <Footer.Icon href="#" icon={BsInstagram} />
            <Footer.Icon href="#" icon={BsTwitter} />
            <Footer.Icon href="#" icon={BsGithub} />
            <Footer.Icon href="#" icon={BsDribbble} />
          </div>
        </div>
      </div>
    </Footer>
  );
}
export default CustomFooter;