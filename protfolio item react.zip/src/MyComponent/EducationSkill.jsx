import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';

const EducationSkill = () => {
  useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true,
    });
  }, []);

  return (
    <section className="py-24 bg-gray-100 dark:bg-gray-900 mt-4" id="EducationSkill">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12" data-aos="fade-up"
      data-aos-delay="400">
          <p className="text-indigo-600 dark:text-indigo-600 text-lg font-semibold">Learning Path</p>
          <h4 className="text-4xl font-bold text-gray-900 dark:text-gray-100">Education & Skills</h4>
        </div>
        <div className="lg:flex lg:space-x-12">
          <div className="lg:w-1/2">
            <div className="mb-8" data-aos="fade-up" data-aos-delay="100">
              <h4 className="text-xl font-bold text-gray-900 dark:text-gray-100">Mansuam University</h4>
              <p className="text-gray-700 dark:text-gray-300">Web Development</p>
              <p className="text-gray-500 dark:text-gray-400">2024</p>
            </div>
            <div className="mb-8" data-aos="fade-up" data-aos-delay="150">
              <h4 className="text-xl font-bold text-gray-900 dark:text-gray-100">Millat Degree College</h4>
              <p className="text-gray-700 dark:text-gray-300">FSC-Pre(Medical)</p>
              <p className="text-gray-500 dark:text-gray-400">2020 - 2022</p>
            </div>
            <div className="mb-8" data-aos="fade-up" data-aos-delay="200">
              <h4 className="text-xl font-bold text-gray-900 dark:text-gray-100">I-Skill</h4>
              <p className="text-gray-700 dark:text-gray-300">Diploma-SEO </p>
              <p className="text-gray-500 dark:text-gray-400">2024</p>
            </div>
          </div>
          <div className="lg:w-1/2">
            <p className="text-gray-700 dark:text-gray-300 mb-8" data-aos="fade-up" data-aos-delay="50">
              For 5+ years, I have been continuously learning in the field of front-end and experimenting with new technologies and frameworks. Here you can see a summary of my skills.
            </p>
            <div className="space-y-4" data-aos="fade-up" data-aos-delay="500">
              <div className="progress-bar" data-aos="fade-up"
      data-aos-delay="400">
                <p className="text-gray-700 dark:text-gray-300 font-medium">React</p>
                <div className="w-full bg-gray-300 dark:bg-gray-700 h-4 rounded-full overflow-hidden">
                  <div className="bg-indigo-600 h-4 rounded-full" style={{ width: '70%' }}></div>
                </div>
              </div>
              <div className="progress-bar">
                <p className="text-gray-700 dark:text-gray-300 font-medium">Css Frameworks</p>
                <div className="w-full bg-gray-300 dark:bg-gray-700 h-4 rounded-full overflow-hidden">
                  <div className="bg-indigo-600 h-4 rounded-full" style={{ width: '93%' }}></div>
                </div>
              </div>
              <div className="progress-bar">
                <p className="text-gray-700 dark:text-gray-300 font-medium">JavaScript</p>
                <div className="w-full bg-gray-300 dark:bg-gray-700 h-4 rounded-full overflow-hidden">
                  <div className="bg-indigo-600 h-4 rounded-full" style={{ width: '55%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EducationSkill;
