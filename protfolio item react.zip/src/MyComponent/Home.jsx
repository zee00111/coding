import Contact from "./Contact";
import Hero from "./Hero";
// import About from "./About";
import Services from "./Services";
import Experience from "./Experience";
import EducationSkill from "./EducationSkill";
import CustomFooter from "./CustomFooter";
import Testimonials from "./Testimonials";
import { useState, } from "react";
import GallerySection from "./GallerySection";


// const Home = () => {
//     const [name, newName] = useState('')
//     function updateState(event) {
//         const value = event.target.value
//         newName(value)
//     }
// // return <>

//     {/* <h1 >{name}</h1>
//     <input type="text" name="" id="" onChange={updateState} value={name} placeholder="name"/> */}
//     {/* <input type="text" name="" id="" onChange={updateState} value={inputValue} placeholder="email"/> */}
//     {/* <button onClick={}>click me</button> */}
//     <Hero />
//     <Services /> 
//     <EducationSkill />
//     <Experience />
//     <Contact /> 
//     {/* <GallerySection /> */}
//     <CustomFooter/>
//     {/* <About /> */}


// </>
// }




const Home = () => {
    return <>
        <Hero />
        <Services />
        <EducationSkill />
        <Experience />
        <Testimonials />
        <Contact />
        <GallerySection />  
        <CustomFooter />
        {/* <About /> */}


    </>
}
export default Home;
