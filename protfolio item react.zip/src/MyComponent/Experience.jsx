import React, { useEffect, useState } from "react";
import AOS from "aos";
// Import dark mode CSS if applicable
import "aos/dist/aos.css";

const Experience = () => {
  useEffect(() => {
    AOS.init({
      duration: 1000,
      once: true,
    });
  }, []);

  const [activeTab, setActiveTab] = useState("Web");

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <section 
      className="py-24 mt-3 bg-gray-100 dark:bg-gray-900"
      data-aos="fade-up"
      data-aos-delay="400"
      id="Experince"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row">
          <div className="lg:w-1/3">
            <div className="mb-8" data-aos="fade-up">
              <p className="text-indigo-600 text-lg font-semibold">
                Career Path
              </p>
              <h2 className="text-4xl font-bold text-gray-900 dark:text-gray-200">
                Work Experience
              </h2>
            </div>
            <div className="mb-8" data-aos="fade-up">
              <ul
                className="space-y-4"
                data-aos="fade-up"
                data-aos-delay="1000"
              >
                <li
                  className={`cursor-pointer dark:text-white ${
                    activeTab === "Web" ? "text-indigo-600 font-bold" : ""
                  }`}
                  onClick={() => handleTabClick("Web")}
                >
                  Web
                </li>
                <li
                  className={`cursor-pointer dark:text-white ${
                    activeTab === "SEO" ? "text-indigo-600 font-bold" : ""
                  }`}
                  onClick={() => handleTabClick("SEO")}
                >
                  SEO
                </li>
                <li
                  className={`cursor-pointer dark:text-white ${
                    activeTab === "E-commerce"
                      ? "text-indigo-600 font-bold"
                      : ""
                  }`}
                  onClick={() => handleTabClick("E-commerce")}
                >
                  E-Commerce
                </li>
              </ul>
            </div>
          </div>
          <div className="lg:w-2/3" data-aos="fade-up" data-aos-delay="1000">
            <div
              className={`mb-8 ${activeTab === "Web" ? "" : "hidden"}`}
              id="Web"
            >
              <div className="mb-4" data-aos="fade-up" data-aos-delay="100">
                <h3 className="text-2xl font-semibold text-gray-900 dark:text-gray-200">
                  Front-end Developer{" "}
                  <span className="text-indigo-600">CIT.Tech</span>
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Multan, Pakistan
                </p>
                <p className="text-gray-600 dark:text-gray-400">
                  6 Months of Experience
                </p>
                <p className="text-gray-600 dark:text-gray-400">
                  Nov 2024 - Present · Part-time
                </p>
                <ul className="flex space-x-2 mt-2">
                  <li className="bg-indigo-600 text-white px-2 py-1 rounded-full">
                    React
                  </li>
                  <li className="bg-indigo-600 text-white px-2 py-1 rounded-full">
                    Tailwind
                  </li>
                </ul>
              </div>
              <div className="line"></div>
              <ul
                className="list-disc list-inside text-gray-700 dark:text-gray-300"
                data-aos="fade-up"
                data-aos-delay="150"
              >
                <li>Create a responsive and visually appealing website .</li>
                <li>
                  Collaborate with back-end developers and web designers to
                  improve usability.
                </li>
                <li>Utilized React to build a dynamic and interactive SPA.</li>
                <li>
                  Developed responsive websites using HTML, CSS, and JavaScript.
                </li>
              </ul>
            </div>
            <div
              className={`mb-8 ${activeTab === "SEO" ? "" : "hidden"}`}
              id="SEO"
            >
              <div className="mb-4" data-aos="fade-up" data-aos-delay="200">
                <h3 className="text-2xl font-semibold text-gray-900 dark:text-gray-200">
                  Seo-Developer <span className="text-indigo-600">I-Skill</span>
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Multan, Pakistan</p>
                <p className="text-gray-600 dark:text-gray-400">
                  6 Months of Experience
                </p>
                <p className="text-gray-600 dark:text-gray-400">
                  Aug 2023 - Feb 2024 · Full-time
                </p>
                <ul className="flex space-x-2 mt-2">
                  <li className="bg-indigo-600 text-white px-2 py-1 rounded-full">
                    On-Page
                  </li>
                  <li className="bg-indigo-600 text-white px-2 py-1 rounded-full">
                    Off-Page
                  </li>
                  <li className="bg-indigo-600 text-white px-2 py-1 rounded-full">
                    Technical
                  </li>
                </ul>
              </div>
              <div className="line"></div>
              <ul
                className="list-disc list-inside text-gray-700 dark:text-gray-300"
                data-aos="fade-up"
                data-aos-delay="250"
              >
                <li>
                  Conducted keyword research to optimize content and improve
                  search rankings.
                </li>
                <li>
                  Implemented on-page SEO strategies, including meta tags and
                  internal linking.
                </li>
                <li>
                  Developed and executed content strategies to increase organic
                  traffic.
                </li>
                <li>
                  Performed technical SEO audits and optimized site structure.
                </li>
              </ul>
            </div>
            <div
              className={`mb-8 ${activeTab === "E-commerce" ? "" : "hidden"}`}
              id="E-commerce"
            >
              <div className="mb-4" data-aos="fade-up" data-aos-delay="300">
                <h3 className="text-2xl font-semibold text-gray-900 dark:text-gray-200">
                  E-Commerce <span className="text-indigo-600">I-Skill</span>
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  California, United States
                </p>
                <p className="text-gray-600 dark:text-gray-400">
                  Feb 2018 - Feb 2020 · Full-time
                </p>
                <ul className="flex space-x-2 mt-2">
                  <li className="bg-indigo-600 text-white px-2 py-1 rounded-full">
                    Blogging
                  </li>
                </ul>
              </div>
              <div className="line"></div>
              <ul
                className="list-disc list-inside text-gray-700 dark:text-white"
                data-aos="fade-up"
                data-aos-delay="350"
              >
                <li>
                  Created engaging blog content to drive traffic and improve
                  customer engagement.
                </li>
                <li>
                  Implemented content marketing strategies to boost product
                  visibility and sales.
                </li>
                <li>
                  Collaborated with the marketing team to develop seasonal and
                  promotional blog posts.
                </li>
                <li>
                  Utilized SEO techniques in blog posts to enhance search engine
                  rankings and organic reach.
                </li>
                <li>
                  Analyzed blog performance metrics to optimize content strategy
                  and increase user retention.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default Experience;
