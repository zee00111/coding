import React, { useEffect, useState } from 'react';

const testimonials = [
  "This is the best service I've ever used!",
  "Fantastic experience with this company.",
  "I would highly recommend this to everyone.",
  "Top-notch support and quality.",
  "An absolute pleasure to work with!"
];

const Testimonial = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };
  useEffect(() => {
    const intervalId = setInterval(() => {
      nextTestimonial();
    }, 1000); // Change testimonial every 3 seconds

    return () => clearInterval(intervalId); // Cleanup interval on unmount
  }, []);

  return (
    <div className="flex flex-col items-center justify-center mt-2 p-4 dark:bg-gray-900">
      <div className="relative w-full max-w-lg p-8 text-lg italic text-center text-gray-800 bg-white border border-gray-200 rounded-lg shadow-md">
        <p className="transition duration-500 transform">
          {testimonials[currentIndex]}
        </p>
      </div>
      <div className="flex items-center mt-4 space-x-4">
        <button
          onClick={prevTestimonial}
          className="px-4 py-2 text-white bg-indigo-500 rounded hover:bg-indigo-600"
        >
          &larr; Prev
        </button>
        <button
          onClick={nextTestimonial}
          className="px-4 py-2 text-white bg-indigo-500 rounded hover:bg-indigo-600"
        >
          Next &rarr;
        </button>
      </div>
    </div>
  );
};

export default Testimonial;
