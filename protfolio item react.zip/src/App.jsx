import React from 'react';
import { createBrowserRouter, createHashRouter, Outlet, RouterProvider } from 'react-router-dom';
import Home from './MyComponent/Home';
import About from './MyComponent/About';
import Contact from './MyComponent/Contact';
import Navbar from './MyComponent/Navbar';
import Login from './MyComponent/Login';
import Fallback from './MyComponent/Fallback';
import Dashboard from './MyComponent/Dashboard';
import CustomCursor from './MyComponent/CustomCursor';
import Services from './MyComponent/Services';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { Link } from 'react-router-dom';
import Testing from './Pages/Testing';

AOS.init();


// const DummComp = () => {
//   return <>

//     {/* <Link to={'/'}>Home</Link>
//     <Link to={'team'}>team</Link>
//     <br />

//     Home page Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum blanditiis veritatis magni excepturi architecto, temporibus eos incidunt, voluptates similique itaque dolorem quidem reiciendis sapiente. Blanditiis harum maxime eum iusto sed cum voluptate aperiam, libero, praesentium obcaecati ut consequuntur et sequi sint id? Deserunt obcaecati labore beatae veniam id omnis aperiam exercitationem aliquam impedit. Enim harum repudiandae quam commodi quaerat, asperiores omnis nostrum nam quas quisquam molestiae iste. Voluptates iusto magni eius corporis itaque qui quisquam, eum ducimus dolorum assumenda laboriosam id pariatur enim expedita tempore excepturi. Nisi neque, sunt adipisci natus omnis at assumenda distinctio fuga harum fugiat dicta excepturi.

//     <h1>Team cmponent here</h1>
//     <Outlet />
//     </>
// }
// const TeamComp = () => {
//   return <>

//     <Link to={'/'}>Home</Link>
//     <Link to={'#team'}>team</Link>
//     <br />

//     Team page Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum blanditiis veritatis magni excepturi architecto, temporibus eos incidunt, voluptates similique itaque dolorem quidem reiciendis sapiente. Blanditiis harum maxime eum iusto sed cum voluptate aperiam, libero, praesentium obcaecati ut consequuntur et sequi sint id? Deserunt obcaecati labore beatae veniam id omnis aperiam exercitationem aliquam impedit. Enim harum repudiandae quam commodi quaerat, asperiores omnis nostrum nam quas quisquam molestiae iste. Voluptates iusto magni eius corporis itaque qui quisquam, eum ducimus dolorum assumenda laboriosam id pariatur enim expedita tempore excepturi. Nisi neque, sunt adipisci natus omnis at assumenda distinctio fuga harum fugiat dicta excepturi.

//   </> */}
// {/* } */}

// import DarkModeToggl from './MyComponent/DarkModeToggle';

// User Layout Component
const UserLayout = () => {
  return (
    <div>
      <Navbar />
      <Outlet />
      <CustomCursor />

    </div>
  );
};

// Admin Layout Component
const AdminLayout = () => {
  return (
    <div>
      <Navbar />
      <div>Sidebar</div>
      <Outlet />
    </div>
  );
};

// User Routes
const userRoutes = [
  {
    element: <UserLayout />,
    children: [
      {
        path: '/',
        element: <Home />,
      },
      // {
      //   path: '/about',
      //   element: <About />,
      // },
      {
        path: '/contact',
        element: <Contact />,
      },
      {
        path: '/Services',
        element: <Services />,
      },
    ],
  },
];

// Admin Routes
const adminRoutes = {
  element: <AdminLayout />,
  children: [
    {
      path: '/dashboard',
      element: <Dashboard />,
    },
    {
      path: '/createstaff',
      element: <h1>Create Staff</h1>,
    },
  ],
};

// Public Routes
const publicRoutes = [
  {
    path: '/login',
    element: <Login />,
  },
];

// Dummy user data
const dummyUser = {
  name: 'zain',
  role: 'User', // Ensure proper casing ("User" or "Admin")
  accountRegistered: true,
  userLogin: true,
};

// const router = createHashRouter([
//   {
//     path: "/",
//     element: <DummComp />,
//     // loader:true,
//     children: [
//       {
//         path: "team",
//         element: <TeamComp />,
//         // loader: true,
//       },
//     ],
//   },
// ]);

// Combine Routes Based on User Role
const routes = [
  ...publicRoutes,
  ...(dummyUser?.role === 'User'
    ? userRoutes
    : dummyUser?.role === 'Admin'
      ? [adminRoutes]
      : []),
  {
    path: '*',
    element: <Fallback user={dummyUser} />,
  },
];

// Create Router
const Router = createBrowserRouter(routes);

const App = () => {
  return (
    <div>
      {/* <RouterProvider router={Router} /> */}
      <Testing />
    </div>
  );
};

export default App;
