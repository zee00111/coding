// import React from 'react'

// const Testing = () => {
//     const [count, setCount] = React.useState(0)
//     // const [name,setname]=React.useState('')
//     // const [email,setemail]=React.useState('')
//     // const [password,setpassword]=React.useState('')

//     // const [posts, setPosts] = React.useState([])
//     // const headingRef = React.useRef()

//     // const [inputs, setInputs] = React.useState({
//     //     username: "",
//     //     email: "",
//     //     password: "",
//     // })

//     // const handleInputs = (e) => {
//     //     const { name, value } = e.target
//     //     setInputs((preVal) => {
//     //         return {
//     //             ...preVal,
//     //             [name]: value
//     //         }
//     //     })
//     // }

//     // const handleSubmit=(e)=>{
//     //     e.preventDefault()
//     //     console.log(inputs)
//     // }

//     const incr = () => {
//         setCount(count + 1)
//     }
//     const decr = () => {
//         if (count <= 0) {
//             return
//         }
//         setCount(count - 1)
//     }

//     const FetchPosts = async () => {
//         // fetch('https://jsonplaceholder.typicode.com/posts')
//         //     .then((response) => response.json())
//         //     .then((posts) => setPosts(posts)).catch((err) => { console.log(err) })

//         try {
//             const allPosts = await fetch('https://jsonplaceholder.typicode.com/posts')
//             setPosts(await allPosts.json())
//         } catch (error) {
//             console.log(error)
//         }
//     }
//     React.useEffect(() => {
//         setTimeout(() => {
//             FetchPosts()
//         }, 2000)
//     },[])
//     console.log('from parent component');
//     return (
//         <div>
//             {count}
//             <br />
//             <button onClick={incr}>increment</button>
//             <br />
//             <button onClick={decr}>decrement</button>
//             {/* name:{inputs.username}
//             email:{inputs.email}
//             pas:{inputs.password} */}
//             {/* <form action="" onSubmit={handleSubmit}>
//                 <input type="text" name="username" id="" placeholder='enter name' value={inputs.name} onChange={handleInputs} />
//                 <input type="email" name="email" id="" placeholder='enter email' value={inputs.email} onChange={handleInputs} />
//                 <input type="password" name="password" id="" placeholder='enter password' value={inputs.password} onChange={handleInputs} />
//                 <button>submit</button>
//             </form> */}

//             {/* <button onClick={FetchPosts} className='px-3 py-1.5 rounded-sm bg-green-500 text-white'>fetch posts</button> */}

//             {/* all posts */}
//             {/* <ul className='flex flex-col gap-2 justify-start items-start px-4 py-4'>
//                 {posts.length >= 1 ? posts.map((val, index, arr) => {
//                     return <li key={val.id} className='bg-orange-300 p-2 rounded-md'>
//                         <span className=''>{val.id}</span>
//                         <h2 className='text-lg font-semibold capitalize pb-2'>{val.title}</h2>
//                         <p>{val.body}</p>
//                     </li>
//                 }) : 'loading....'}
//             </ul> */}

//             {/* <h1 ref={headingRef}>abc</h1> */}
//             <h1 className='text-lg font-semibold capitalize pb-2'>this is from parent component</h1>
//             <SecondComp count={count} />/
//         </div>
//     )
// }
// export default Testing


// const SecondComp = React.memo(({ count }) => {
//     console.log('from child component', count);
//     return <h1 className='text-lg font-semibold capitalize pb-2'>this is 2nd component means child</h1>
// })


// import React, { useState } from 'react';

// function Testing() {
//   // Declare a state variable named "count" and a function to update it "setCount"
//   const [count, setCount] = useState(0);

//   // Function to increment the count
//   const increment = () => setCount(count + 1);
//   const decriment = () =>{
//     if (count<=0){
//         return

//     }
//     setCount(count - 1);

//   }
//   return (
//     <div>
//       <p>Count: {count}</p>
//       <button onClick={increment}>Increment</button>
//       <hr />
//       <button onClick={decriment}>decriment</button>
//     </div>
//   );
// }

// export default Testing;
import { split } from 'postcss/lib/list';
import React, { useState, useEffect } from 'react';

function Testing() {
  const [matchMedia, setSeconds] = useState(0);
  const [text, setText] = useState('');
  let handleChange = (e) => {
    setText(e.target.value);
  };
  let handleClick = () => {
    setText(text.toUpperCase());
  };

  useEffect(() => {
    // Function to increment the seconds
    const interval = setInterval(() => {
      setSeconds((prevmatchmedia) => prevmatchmedia + 1);
    }, 1000);

    // Cleanup function to clear the interval
    return () => clearInterval(interval);
  }, []);

  return (



    <div>
      {/* <p>{count}</p> */}
      <div>
        <hr />
        <br />
      <p   className='bg-gray-300 text-black'> {text.split} {text.length} text length</p>
      <hr />
<hr />       {text}

<h1 className='bg-indigo-400' contentEditable>EDITABLE Text if you write then you can edit it its build in </h1>
 
        <textarea className='m-10 mb-10 p-5 bg-gray-900 text-white justify-center'
          value={text}
          onChange={handleChange}
          cols={30}g
          rows={20}
          name=""
          id=""
        />
        <textarea className='m-10 mb-10 p-5 bg-gray-900 text-white justify-center'
          value={text}
          onChange={handleChange}
          cols={30}
          rows={20}
          name=""
          id=""
        />
        <button className='mt-3 bg-indigo-600 text-white p-2' onClick={handleClick}>Click it</button>
      </div>


      <p>Seconds: {matchMedia}</p>
      {/* <button className='rouunded-33 bg-red-950 text-white' onClick={{}} id='tn'>button </button> */}
    </div>
  );
}

export default Testing;
